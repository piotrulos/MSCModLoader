﻿using MSCLoader;
using UnityEngine;

namespace $safeprojectname$  
{
    public class $safeprojectname$ : Mod
    {
        public override string ID { get { return "$safeprojectname$"; } } 
        public override string Name { get { return "$projectname$"; } } 
        public override string Author { get { return "Your Username"; } } 
        public override string Version { get { return "1.0"; } }

        //Called when mod is loading
        public override void OnLoad()
        {
           
        }

        // Update is called once per frame
        public override void Update()
        {
           
        }
    }
}

﻿using MSCLoader;
using UnityEngine;

//Standard MSCLoader mod class
namespace $rootnamespace$  
{
    public class $safeitemname$ : Mod
    {
        public override string ID => "$safeitemname$"; 
        public override string Name => "$itemname$";
        public override string Author => "Your Username";
        public override string Version => "1.0";

	//Set this to true if you will be load custom assets from Assets folder.
	//This will create subfolder in Assets folder for your mod.
	public override bool UseAssetsFolder => false;

        //Called when mod is loading
        public override void OnLoad()
        {
           
        }

        // Update is called once per frame
        public override void Update()
        {
           
        }
    }
}

﻿using MSCLoader;
using UnityEngine;

//Standard MSCLoader mod class
namespace $rootnamespace$  
{
    public class $safeitemname$ : Mod
    {
        public override string ID { get { return "$safeitemname$"; } } 
        public override string Name { get { return "$itemname$"; } } 
        public override string Author { get { return "Your Username"; } } 
        public override string Version { get { return "1.0"; } }

        //Called when mod is loading
        public override void OnLoad()
        {
           
        }

        // Update is called once per frame
        public override void Update()
        {
           
        }
    }
}

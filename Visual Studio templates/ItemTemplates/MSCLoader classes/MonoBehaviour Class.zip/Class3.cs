﻿using MSCLoader;
using UnityEngine;

//Standard unity MonoBehaviour class
namespace $rootnamespace$
{
    public class $safeitemname$ : MonoBehaviour
    {
    	// Use this for initialization
	    void Start()
        {
            
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
